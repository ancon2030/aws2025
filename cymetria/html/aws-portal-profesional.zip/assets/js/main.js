/* Funciones del portal */
(function(){
  const $ = (sel,ctx=document)=>ctx.querySelector(sel);
  const $$ = (sel,ctx=document)=>Array.from(ctx.querySelectorAll(sel));

  // Año footer
  $('#y').textContent = new Date().getFullYear();

  // Menú responsive
  const toggle = $('#navToggle'), menu = $('#navMenu');
  toggle?.addEventListener('click', ()=>{
    const open = menu.classList.toggle('open');
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  });

  // Tema
  const themeBtn = $('#themeBtn');
  themeBtn?.addEventListener('click', ()=>{
    document.body.classList.toggle('light');
  });

  // Animación on-scroll
  const io = new IntersectionObserver(entries => {
    entries.forEach(e=>{
      if(e.isIntersecting) e.target.classList.add('reveal');
    });
  }, {threshold:.15});
  $$('.card,.ref,.case').forEach(el=>io.observe(el));

  // Formulario
  const form = $('#contactForm');
  const status = $('#formStatus');

  function setStatus(msg, ok=false){
    status.textContent = msg;
    status.style.color = ok ? 'var(--ok)' : '#ffb3b3';
  }

  function validate(form){
    let valid = true;
    $$('input[required],textarea[required]', form).forEach(el=>{
      const wrap = el.closest('.field');
      const small = $('.err', wrap);
      let ok = true;
      if(!el.value.trim()) ok = false;
      if(el.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(el.value)) ok = false;
      small.style.display = ok ? 'none' : 'block';
      valid = valid && ok;
    });
    return valid;
  }

  form?.addEventListener('submit', async (e)=>{
    e.preventDefault();
    if(!validate(form)){ setStatus('Revisa los campos obligatorios.'); return; }

    const data = Object.fromEntries(new FormData(form).entries());
    setStatus('Enviando...');

    // DEMO: guarda localmente; PROD: llama a API_URL
    try{
      if(CONFIG.DEMO_MODE || !CONFIG.API_URL){
        const inbox = JSON.parse(localStorage.getItem('inbox') || '[]');
        inbox.push({...data, date: new Date().toISOString()});
        localStorage.setItem('inbox', JSON.stringify(inbox));
        setStatus('Mensaje almacenado en demo. Configura API_URL para envío real.', true);
        form.reset();
      }else{
        const res = await fetch(CONFIG.API_URL, {
          method: 'POST',
          headers: {'Content-Type':'application/json'},
          body: JSON.stringify(data)
        });
        if(!res.ok) throw new Error('HTTP '+res.status);
        setStatus('Mensaje enviado con éxito.', true);
        form.reset();
      }
    }catch(err){
      console.error(err);
      setStatus('No se pudo enviar. Reintenta o verifica tu API.');
    }
  });
})();
