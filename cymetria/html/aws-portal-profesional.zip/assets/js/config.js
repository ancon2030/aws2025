// Configuración del portal
// Para producción, configura tu endpoint (API Gateway + Lambda + SES) y desactiva DEMO_MODE
const CONFIG = {
  API_URL: "",            // Ej.: "https://abcde.execute-api.us-east-1.amazonaws.com/prod/contact"
  DEMO_MODE: true         // Cambia a false para usar API_URL
};
