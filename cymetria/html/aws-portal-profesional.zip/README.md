# AWS Cloud Portal (estático)

Portal web profesional sobre servicios de AWS. Pensado para ser empaquetado como **ZIP** y usado por CodeBuild para generar una imagen NGINX que se publica en **ECR**.

## Estructura
- `index.html` — Página principal (responsive, accesible).
- `assets/css/styles.css` — Estilos modernos (tema oscuro claro).
- `assets/js/config.js` — Ajustes de la app (API_URL y DEMO_MODE).
- `assets/js/main.js` — Lógica (navegación, animaciones, formulario).
- `assets/img/` — Carpeta para imágenes si deseas añadir.

## Envío de correos (mini‑motor)
- Por defecto está en **DEMO_MODE**: el formulario guarda mensajes en `localStorage`.
- Para producción:
  1. Crea endpoint en **API Gateway** que invoque una **Lambda**.
  2. La Lambda envía correo con **Amazon SES** (dominio/remitente verificados).
  3. Configura `CONFIG.API_URL` en `assets/js/config.js` y `DEMO_MODE=false`.

Ejemplo de payload que enviará el front:
```json
{ "name":"", "email":"", "message":"" }
```

## Uso como ZIP (AppZipUrl)
1. Genera el ZIP de esta carpeta.
2. Sube el archivo a un hosting accesible (por ejemplo, **GitHub Releases**) y usa su URL en el parámetro `AppZipUrl` del template de CloudFormation.
3. CodeBuild descargará el ZIP, construirá la imagen (`nginx:alpine`) y la publicará en **ECR**.
